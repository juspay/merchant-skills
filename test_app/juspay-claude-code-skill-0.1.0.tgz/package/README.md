# Juspay Claude Code Skill

AI-powered Juspay integration assistant for [Claude Code](https://docs.anthropic.com/en/docs/claude-code/overview).

## Quick Start

```bash
# Install
npm install -g @juspay/claude-code-skill

# Initialize (first time)
juspay-claude init

# Launch with Juspay context
juspay-claude
```

## What It Does

1. **Registers MCP server** — Calls `claude mcp add --scope user` to register the Juspay Docs MCP server in Claude Code's user-scope config.
2. **Installs skills** — Writes `juspay-explainer/SKILL.md` and `juspay-integrator/SKILL.md` under `~/.claude/skills/`.
3. **Pre-fills context** — Your `merchant_id`, `client_id`, and environment are substituted into the skill templates.

## Skills Included

| Skill | Purpose | When to Use |
|-------|---------|-------------|
| `juspay-explainer` | Conceptual docs | "What is Outages?", "Explain UPI flows" |
| `juspay-integrator` | Implementation help | "How to integrate Payment Page", "Show me the payload" |

## Commands

```bash
juspay-claude              # Launch Claude Code with Juspay context
juspay-claude init         # Re-configure merchant settings
```

## Configuration

Stored in `~/.config/genius/config.json`:

```json
{
  "merchant_id": "your_merchant",
  "client_id": "your_client",
  "environment": "sandbox"
}
```

## MCP Servers

The package registers one MCP server at user scope:

- `juspay-docs` — `https://mcp.juspay.in/dashboard/juspay-docs-stream`

To add it manually:

```bash
claude mcp add --scope user --transport http \
  juspay-docs https://mcp.juspay.in/dashboard/juspay-docs-stream
```

To inspect or remove:

```bash
claude mcp list
claude mcp remove --scope user juspay-docs
```

## Requirements

- Node.js 18+
- Claude Code installed (`npm install -g @anthropic-ai/claude-code`)

## License

MIT
